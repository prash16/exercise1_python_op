from .sd import standard_deviation
