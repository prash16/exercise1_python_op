from distutils.core import setup

setup(
    name='exercise1_python_op',
    version='0.1dev',
    packages=['exercise1_op',],
    long_description=open('README.md').read(),
)
